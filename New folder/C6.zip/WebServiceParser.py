import xmltodict
import json

all_exp = []

file = input('Enter xml file name? = ')


def js_to_xml(asp):
    exp = {}
    if "@name" in asp:
        exp["method_name"] = asp['@name']
    if "visibility" in asp:
        exp["visibility"] = asp["visibility"]

    all_exp = []
    li = []

    if "exceptions" in asp:
        if type(asp["exceptions"]["exception"]) == str:
            li.append(asp["exceptions"]["exception"])
        if type(asp["exceptions"]["exception"]) == list:
            for act in asp["exceptions"]["exception"]:
                li.append(act)
        exp["exceptions"] = {"exception": li}

    if "arguments" in asp:
        for term in asp["arguments"]:
            if type(asp["arguments"][term]) == list:
                for vl in asp["arguments"][term]:
                    lis = {"datatype": vl["@type"], "label": vl["#text"]}
                    all_exp.append(lis)
            if type(asp["arguments"][term]) == dict:
                vl = asp["arguments"][term]
                lis = {"datatype": vl["@type"], "label": vl["#text"]}
                all_exp.append(lis)
        exp["arguments"] = {"parameter": all_exp}

    if "return" in asp:
        exp["return"] = asp["return"]
    return exp


with open(file) as file_xml:
    xml = xmltodict.parse(file_xml.read())

    temp = xml["service"]["abstract_method"]

    if type(temp) == dict:
        exp = js_to_xml(temp)
        all_exp.append(exp)

    if type(temp) == list:
        for asp in temp:
            exp = js_to_xml(asp)
            all_exp.append(exp)

    object = {"abstract_method": all_exp}
    js_file_data = json.dumps(object, indent=2)
    print(js_file_data)
