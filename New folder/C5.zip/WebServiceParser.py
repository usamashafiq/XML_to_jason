import xmltodict
import json


def xml_conv(meta):
    words = {}
    if "@name" in meta:
        words["method_name"] = meta['@name']
    if "visibility" in meta:
        words["visibility"] = meta["visibility"]
    all_word = []
    wo = []

    if "exceptions" in meta:
        if type(meta["exceptions"]["exception"]) == str:
            wo.append(meta["exceptions"]["exception"])
        if type(meta["exceptions"]["exception"]) == list:
            for act in meta["exceptions"]["exception"]:
                wo.append(act)
        words["exceptions"] = {"exception": wo}

    if "arguments" in meta:
        for para in meta["arguments"]:
            if type(meta["arguments"][para]) == list:
                for value in meta["arguments"][para]:
                    arr = {"datatype": value["@type"], "label": value["#text"]}
                    all_word.append(arr)
            if type(meta["arguments"][para]) == dict:
                value = meta["arguments"][para]
                arr = {"datatype": value["@type"], "label": value["#text"]}
                all_word.append(arr)
        words["arguments"] = {"parameter": all_word}

    if "return" in meta:
        words["return"] = meta["return"]
    return words


# def analyze(f_user):
all_word = []


def main():
    # input the file from user
    file = input('Enter xml file name? = ')

    with open(file) as file:

        xml = xmltodict.parse(file.read())

        temp = xml["service"]["abstract_method"]

        if type(temp) == dict:
            words = xml_conv(temp)
            all_word.append(words)

        if type(temp) == list:
            for meta in temp:
                words = xml_conv(meta)
                all_word.append(words)

        OBJ = {"abstract_method": all_word}
        json_for = json.dumps(OBJ, indent=2)
        print(json_for)


if __name__ == '__main__':
    main()
