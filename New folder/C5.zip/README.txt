do before run the code

install this using pip xmltodict

open IDE or terminal then use this

python WebServiceParser.py filename.xml

xml file must in same folder
