Guide

install this python -m pip install xmltodict

command>>

python WebServiceParser.py filename

input the WebService.xml file 
