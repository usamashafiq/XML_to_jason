import xmltodict
import json


def xml_conv(info):
    info_dict = {}
    if "@name" in info:
        info_dict["method_name"] = info['@name']
    if "visibility" in info:
        info_dict["visibility"] = info["visibility"]
    all_info = []
    ch = []

    if "exceptions" in info:
        if type(info["exceptions"]["exception"]) == str:
            ch.append(info["exceptions"]["exception"])
        if type(info["exceptions"]["exception"]) == list:
            for quirk in info["exceptions"]["exception"]:
                ch.append(quirk)
        info_dict["exceptions"] = {"exception": ch}

    if "arguments" in info:
        for para in info["arguments"]:
            if type(info["arguments"][para]) == list:
                for value in info["arguments"][para]:
                    garb = {"datatype": value["@type"], "label": value["#text"]}
                    all_info.append(garb)
            if type(info["arguments"][para]) == dict:
                value = info["arguments"][para]
                garb = {"datatype": value["@type"], "label": value["#text"]}
                all_info.append(garb)
        info_dict["arguments"] = {"parameter": all_info}

    if "return" in info:
        info_dict["return"] = info["return"]
    return info_dict


def analyze(f_user):
    all_info = []
    with open(f_user) as file:

        xml = xmltodict.parse(file.read())

        temporary = xml["service"]["abstract_method"]

        if type(temporary) == list:
            for info in temporary:
                info_dict = xml_conv(info)
                all_info.append(info_dict)

        if type(temporary) == dict:
            info_dict = xml_conv(temporary)
            all_info.append(info_dict)

        OBJ = {"abstract_method": all_info}
        json_for = json.dumps(OBJ, indent=2)
        print(json_for)


def main():
    # input the file from user
    file = input('After xml processing, return the abstract methods in json format. file name? = ')
    analyze(file)


if __name__ == '__main__':
    main()
