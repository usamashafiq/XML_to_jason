
##Fist install these things
xmltodict
json

##then open the .py file in terminal or IDE 

when you run the script it is asked the file please input complet file python do not enter only 
file name

when use file in terminal use this command

python WebServiceParser.py 

then you will see the output in console


