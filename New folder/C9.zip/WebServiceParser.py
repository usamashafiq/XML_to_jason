import xmltodict
import json


# define a function which has all functionality
def main():
    # user input
    user_in = input("XMl file name :::  ")
    print(" ")

    empty = []
    with open(user_in) as reader:
        store_file = xmltodict.parse(reader.read())
        meth_xm = store_file["service"]["abstract_method"]
        ch_xml_d_typ = type(meth_xm)

        # check the type is dict or list
        if ch_xml_d_typ == dict:

            after_parametersar = {}

            if "@name" in ch_xml_d_typ:
                after_parametersar["method_name"] = ch_xml_d_typ['@name']
            if "visibility" in ch_xml_d_typ:
                after_parametersar["visibility"] = ch_xml_d_typ["visibility"]
            parameterams = []
            ex = []

            # check the exception in checktype
            if "exceptions" in ch_xml_d_typ:
                if type(ch_xml_d_typ["exceptions"]["exception"]) == str:
                    ex.append(ch_xml_d_typ["exceptions"]["exception"])
                if type(ch_xml_d_typ["exceptions"]["exception"]) == list:
                    for exep in ch_xml_d_typ["exceptions"]["exception"]:
                        ex.append(exep)
                after_parametersar["exceptions"] = {"exception": ex}
            if "return" in ch_xml_d_typ:
                after_parametersar["return"] = ch_xml_d_typ["return"]

            if "arguments" in ch_xml_d_typ:
                for parameter in ch_xml_d_typ["arguments"]:
                    if type(ch_xml_d_typ["arguments"][parameter]) == list:
                        for dat in ch_xml_d_typ["arguments"][parameter]:
                            garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                            parameterams.append(garbage)
                    if type(ch_xml_d_typ["arguments"][parameter]) == dict:
                        dat = ch_xml_d_typ["arguments"][parameter]
                        garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                        parameterams.append(garbage)
                after_parametersar["arguments"] = {"parameter": parameterams}

            empty.append(after_parametersar)

        if ch_xml_d_typ == list:
            after_parametersar = {}
            for ch_xml_d_typ in meth_xm:
                after_parametersar = {}
                if "@name" in ch_xml_d_typ:
                    after_parametersar["method_name"] = ch_xml_d_typ['@name']
                if "visibility" in ch_xml_d_typ:
                    after_parametersar["visibility"] = ch_xml_d_typ["visibility"]
                parameterams = []
                ex = []

                if "arguments" in ch_xml_d_typ:
                    for parameter in ch_xml_d_typ["arguments"]:
                        if type(ch_xml_d_typ["arguments"][parameter]) == list:
                            for dat in ch_xml_d_typ["arguments"][parameter]:
                                garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                                parameterams.append(garbage)
                        if type(ch_xml_d_typ["arguments"][parameter]) == dict:
                            dat = ch_xml_d_typ["arguments"][parameter]
                            garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                            parameterams.append(garbage)
                    after_parametersar["arguments"] = {"parameter": parameterams}

                if "exceptions" in ch_xml_d_typ:
                    if type(ch_xml_d_typ["exceptions"]["exception"]) == str:
                        ex.append(ch_xml_d_typ["exceptions"]["exception"])
                    if type(ch_xml_d_typ["exceptions"]["exception"]) == list:
                        for exep in ch_xml_d_typ["exceptions"]["exception"]:
                            ex.append(exep)
                    after_parametersar["exceptions"] = {"exception": ex}
                if "return" in ch_xml_d_typ:
                    after_parametersar["return"] = ch_xml_d_typ["return"]

                empty.append(after_parametersar)
        # json object to convert a json
        parsar_obj = {"abstract_method": empty}
        Str_dict = json.dumps(parsar_obj, indent=2)
        print("Data converted xml to json")
        print(Str_dict)

        with open("WebService.json", "w") as outfile:
            print("New json file is created from WebService.jso file")
            outfile.write(Str_dict)


if __name__ == '__main__':
    main()
