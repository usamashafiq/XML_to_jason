guidence to run the script

install the xmltodict

python WebServiceParser.py filename

please xml file place in folder have a code

after see the output in output file 
