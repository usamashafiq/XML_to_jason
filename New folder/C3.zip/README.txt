instructions
Install::
pip install xmltodict xml json

command::
python WebServiceParser.py -f type file name

input the file name extension is  .xml 
