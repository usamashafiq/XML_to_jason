import argparse
import xmltodict
import json


# create the json file in this function
def Js_conv(txt):
    # create a dict
    txt_dict = {}
    if "@name" in txt:
        txt_dict["method_name"] = txt['@name']
    if "visibility" in txt:
        txt_dict["visibility"] = txt["visibility"]
    data_List = []
    qu = []
    # check the exception in xml txt
    if "exceptions" in txt:
        if type(txt["exceptions"]["exception"]) == str:
            qu.append(txt["exceptions"]["exception"])
        if type(txt["exceptions"]["exception"]) == list:
            for quirk in txt["exceptions"]["exception"]:
                qu.append(quirk)
        txt_dict["exceptions"] = {"exception": qu}
    # check the arguments in txt
    if "arguments" in txt:
        for par in txt["arguments"]:
            if type(txt["arguments"][par]) == list:
                for val in txt["arguments"][par]:
                    Temp = {"datatype": val["@type"], "label": val["#text"]}
                    data_List.append(Temp)
            if type(txt["arguments"][par]) == dict:
                val = txt["arguments"][par]
                Temp = {"datatype": val["@type"], "label": val["#text"]}
                data_List.append(Temp)
        txt_dict["arguments"] = {"parameter":data_List}
    # if the last is return in txt
    if "return" in txt:
        txt_dict["return"] = txt["return"]
    return txt_dict


# parse the data in xml file
def analyze(f_user):
    # create a list
    data_list = []
    with open(f_user) as file:
        # parse the data in xml file
        xml = xmltodict.parse(file.read())
        try:
            # check the xml file formate
            brief = xml["service"]["abstract_method"]
        except:
            print("At least one abstract method is absent.")
            return

        if type(brief) == list:
            for txt in brief:
                txt_dict = Js_conv(txt)
                data_list.append(txt_dict)

        if type(brief) == dict:
            txt_dict = Js_conv(brief)
            data_list.append(txt_dict)

        OBJ = {"abstract_method": data_list}
        json_for = json.dumps(OBJ, indent=2)
        print(json_for)


def main():
    command_line = argparse.ArgumentParser(description='After xml processing, return the abstract methods in json format.'
                                                    'file.')
    command_line.add_argument('-f', '--file', help='file name', required=True)
    inPut = vars(command_line.parse_args())
    f_user = inPut['file']
    analyze(f_user)


if __name__ == '__main__':
    main()
