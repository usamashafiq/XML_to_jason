import xmltodict
import json


# define a function which has all functionality
def main():
    # user input
    user_in = input("Enter the file you want to convert ")

    xml_list = []
    with open(user_in) as reader:
        store_file = xmltodict.parse(reader.read())
        meth_xm = store_file["service"]["abstract_method"]
        check_typ = type(meth_xm)

        # check the type is dict or list
        if check_typ == dict:

            after_parametersar = {}

            if "@name" in check_typ:
                after_parametersar["method_name"] = check_typ['@name']
            if "visibility" in check_typ:
                after_parametersar["visibility"] = check_typ["visibility"]
            parameterams = []
            ex = []

            if "arguments" in check_typ:
                for parameter in check_typ["arguments"]:
                    if type(check_typ["arguments"][parameter]) == list:
                        for dat in check_typ["arguments"][parameter]:
                            garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                            parameterams.append(garbage)
                    if type(check_typ["arguments"][parameter]) == dict:
                        dat = check_typ["arguments"][parameter]
                        garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                        parameterams.append(garbage)
                after_parametersar["arguments"] = {"parameter": parameterams}

            # check the exception in checktype
            if "exceptions" in check_typ:
                if type(check_typ["exceptions"]["exception"]) == str:
                    ex.append(check_typ["exceptions"]["exception"])
                if type(check_typ["exceptions"]["exception"]) == list:
                    for exep in check_typ["exceptions"]["exception"]:
                        ex.append(exep)
                after_parametersar["exceptions"] = {"exception": ex}
            if "return" in check_typ:
                after_parametersar["return"] = check_typ["return"]

            xml_list.append(after_parametersar)

        if check_typ == list:
            after_parametersar = {}
            for check_typ in meth_xm:
                after_parametersar = {}
                if "@name" in check_typ:
                    after_parametersar["method_name"] = check_typ['@name']
                if "visibility" in check_typ:
                    after_parametersar["visibility"] = check_typ["visibility"]
                parameterams = []
                ex = []

                if "arguments" in check_typ:
                    for parameter in check_typ["arguments"]:
                        if type(check_typ["arguments"][parameter]) == list:
                            for dat in check_typ["arguments"][parameter]:
                                garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                                parameterams.append(garbage)
                        if type(check_typ["arguments"][parameter]) == dict:
                            dat = check_typ["arguments"][parameter]
                            garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                            parameterams.append(garbage)
                    after_parametersar["arguments"] = {"parameter": parameterams}

                if "exceptions" in check_typ:
                    if type(check_typ["exceptions"]["exception"]) == str:
                        ex.append(check_typ["exceptions"]["exception"])
                    if type(check_typ["exceptions"]["exception"]) == list:
                        for exep in check_typ["exceptions"]["exception"]:
                            ex.append(exep)
                    after_parametersar["exceptions"] = {"exception": ex}
                if "return" in check_typ:
                    after_parametersar["return"] = check_typ["return"]

                xml_list.append(after_parametersar)
        # jason object to convet a json
        js_ob = {"abstract_method": xml_list}
        json_str = json.dumps(js_ob, indent=2)
        # print(json_str)

        with open("OutPut.json", "w") as outfile:
            print("check the present folder output file name is sample.json ")
            outfile.write(json_str)


if __name__ == '__main__':
    main()
