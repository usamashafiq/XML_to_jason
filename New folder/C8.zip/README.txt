if you face the error please install xmltodict using pip or python

run the script via any IDE or command line

python WebServiceParser.py filename

file name mean xml file name

after parse you see the output in script folder
