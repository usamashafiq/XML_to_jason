
xmltodict install this via IDE or cmd using pip or pythn -m
then use the script

place the xml file in code folder.

python WebServiceParser.py xml file

