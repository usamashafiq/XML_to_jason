import xmltodict
import json


def func_conv(item):
    collect_data = {}
    all_data = []
    li = []
    if "@name" in item:
        collect_data["method_name"] = item['@name']
    if "visibility" in item:
        collect_data["visibility"] = item["visibility"]

    if "return" in item:
        collect_data["return"] = item["return"]

    if "arguments" in item:
        for check_in in item["arguments"]:
            if type(item["arguments"][check_in]) == list:
                for ent in item["arguments"][check_in]:
                    fil = {"datatype": ent["@type"], "label": ent["#text"]}
                    all_data.append(fil)
            if type(item["arguments"][check_in]) == dict:
                ent = item["arguments"][check_in]
                fil = {"datatype": ent["@type"], "label": ent["#text"]}
                all_data.append(fil)
        collect_data["arguments"] = {"parameter": all_data}

    if "exceptions" in item:
        if type(item["exceptions"]["exception"]) == str:
            li.append(item["exceptions"]["exception"])
        if type(item["exceptions"]["exception"]) == list:
            for act in item["exceptions"]["exception"]:
                li.append(act)
        collect_data["exceptions"] = {"exception": li}

    return collect_data


Xml = input('Type xml file here  ')
all_data = []
with open(Xml) as file_xml:
    read_file = xmltodict.parse(file_xml.read())

    interim = read_file["service"]["abstract_method"]

    if type(interim) == dict:
        collect_data = func_conv(interim)
        all_data.append(collect_data)

    if type(interim) == list:
        for item in interim:
            collect_data = func_conv(item)
            all_data.append(collect_data)

    jason_obj = {"abstract_method": all_data}
    js_data = json.dumps(jason_obj, indent=2)
    print(js_data)
