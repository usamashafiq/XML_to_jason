import xmltodict
import json



# function do the parsar
def parsar_and_converter(tp_hold_holder):
    
    list_check = []

    typ_checker = type(tp_hold_holder)

    # check the type is dict or list
    if typ_checker == dict:

        list_for_xml_holder = {}

        if "@name" in typ_checker:
            list_for_xml_holder["method_name"] = typ_checker['@name']
        if "visibility" in typ_checker:
            list_for_xml_holder["visibility"] = typ_checker["visibility"]
        temp_tp_hold_holder = []
        list_holder = []

        # check the exception in check type
        if "exceptions" in typ_checker:
            if type(typ_checker["exceptions"]["exception"]) == str:
                list_holder.append(typ_checker["exceptions"]["exception"])
            if type(typ_checker["exceptions"]["exception"]) == list:
                for holder in typ_checker["exceptions"]["exception"]:
                    list_holder.append(holder)
            list_for_xml_holder["exceptions"] = {"exception": list_holder}
        if "return" in typ_checker:
            list_for_xml_holder["return"] = typ_checker["return"]

        if "arguments" in typ_checker:
            for parameter in typ_checker["arguments"]:
                if type(typ_checker["arguments"][parameter]) == list:
                    for tp_hold in typ_checker["arguments"][parameter]:
                        garbage = {"datatype": tp_hold["@type"], "label": tp_hold["#text"]}
                        temp_tp_hold_holder.append(garbage)
                if type(typ_checker["arguments"][parameter]) == dict:
                    tp_hold = typ_checker["arguments"][parameter]
                    garbage = {"datatype": tp_hold["@type"], "label": tp_hold["#text"]}
                    temp_tp_hold_holder.append(garbage)
            list_for_xml_holder["arguments"] = {"parameter": temp_tp_hold_holder}

        list_check.append(list_for_xml_holder)

    if typ_checker == list:
        list_for_xml_holder = {}
        for typ_checker in tp_hold_holder:
            list_for_xml_holder = {}
            if "@name" in typ_checker:
                list_for_xml_holder["method_name"] = typ_checker['@name']
            if "visibility" in typ_checker:
                list_for_xml_holder["visibility"] = typ_checker["visibility"]
            temp_tp_hold_holder = []
            ex = []

            if "arguments" in typ_checker:
                for parameter in typ_checker["arguments"]:
                    if type(typ_checker["arguments"][parameter]) == list:
                        for tp_hold in typ_checker["arguments"][parameter]:
                            garbage = {"datatype": tp_hold["@type"], "label": tp_hold["#text"]}
                            temp_tp_hold_holder.append(garbage)
                    if type(typ_checker["arguments"][parameter]) == dict:
                        tp_hold = typ_checker["arguments"][parameter]
                        garbage = {"datatype": tp_hold["@type"], "label": tp_hold["#text"]}
                        temp_tp_hold_holder.append(garbage)
                list_for_xml_holder["arguments"] = {"parameter": temp_tp_hold_holder}

            if "exceptions" in typ_checker:
                if type(typ_checker["exceptions"]["exception"]) == str:
                    ex.append(typ_checker["exceptions"]["exception"])
                if type(typ_checker["exceptions"]["exception"]) == list:
                    for holder in typ_checker["exceptions"]["exception"]:
                        ex.append(holder)
                list_for_xml_holder["exceptions"] = {"exception": ex}
            if "return" in typ_checker:
                list_for_xml_holder["return"] = typ_checker["return"]

            list_check.append(list_for_xml_holder)

    # abstract_method from xml file and make json file
    parsar_obj = {"abstract_method": list_check}
    Str_dict = json.dumps(parsar_obj, indent=2)
    return Str_dict


def file_make(files):
    with open("WebService.json", "w") as outfile:
        print("New json file is created name is WebService.json check is folder")
        outfile.write(files)

# file input

def input_file():
    user_in = input("Enter file name ***  ")
    with open(user_in) as reader:
        object_xml = xmltodict.parse(reader.read())
        tp_hold_holder = object_xml["service"]["abstract_method"]
        return tp_hold_holder


if __name__ == '__main__':
    # file input from user and function call
    file = input_file()
    # pass the file to parsar
    tp_hold = parsar_and_converter(file)
    print("XML converted successful")
    # file maker
    file_make(tp_hold)
