install the following library

xmltodict install via IDE or termical

WebServiceParser.py file open in IDE or find the file via termial then run this file

enter the xml file which you want to pars webservice.xml and place the file in folder

you see the file which have output of the xml to json
