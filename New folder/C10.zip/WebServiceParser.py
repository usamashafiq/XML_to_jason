import xmltodict
import json


# file input 

def input_file():
    user_in = input("Enter file name ***  ")

    with open(user_in) as reader:
        enter_file = xmltodict.parse(reader.read())
        method_xml_fil = enter_file["service"]["abstract_method"]
        return method_xml_fil


# function do the parsar
def main():
    # user input
    method_xml_fil = input_file()
    list_check = []

    con_file_typ = type(method_xml_fil)

    # check the type is dict or list
    if con_file_typ == dict:

        methods = {}

        if "@name" in con_file_typ:
            methods["method_name"] = con_file_typ['@name']
        if "visibility" in con_file_typ:
            methods["visibility"] = con_file_typ["visibility"]
        data_xml = []
        ex = []

        # check the exception in check type
        if "exceptions" in con_file_typ:
            if type(con_file_typ["exceptions"]["exception"]) == str:
                ex.append(con_file_typ["exceptions"]["exception"])
            if type(con_file_typ["exceptions"]["exception"]) == list:
                for exep in con_file_typ["exceptions"]["exception"]:
                    ex.append(exep)
            methods["exceptions"] = {"exception": ex}
        if "return" in con_file_typ:
            methods["return"] = con_file_typ["return"]

        if "arguments" in con_file_typ:
            for parameter in con_file_typ["arguments"]:
                if type(con_file_typ["arguments"][parameter]) == list:
                    for dat in con_file_typ["arguments"][parameter]:
                        garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                        data_xml.append(garbage)
                if type(con_file_typ["arguments"][parameter]) == dict:
                    dat = con_file_typ["arguments"][parameter]
                    garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                    data_xml.append(garbage)
            methods["arguments"] = {"parameter": data_xml}

        list_check.append(methods)

    if con_file_typ == list:
        methods = {}
        for con_file_typ in method_xml_fil:
            methods = {}
            if "@name" in con_file_typ:
                methods["method_name"] = con_file_typ['@name']
            if "visibility" in con_file_typ:
                methods["visibility"] = con_file_typ["visibility"]
            data_xml = []
            ex = []

            if "arguments" in con_file_typ:
                for parameter in con_file_typ["arguments"]:
                    if type(con_file_typ["arguments"][parameter]) == list:
                        for dat in con_file_typ["arguments"][parameter]:
                            garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                            data_xml.append(garbage)
                    if type(con_file_typ["arguments"][parameter]) == dict:
                        dat = con_file_typ["arguments"][parameter]
                        garbage = {"datatype": dat["@type"], "label": dat["#text"]}
                        data_xml.append(garbage)
                methods["arguments"] = {"parameter": data_xml}

            if "exceptions" in con_file_typ:
                if type(con_file_typ["exceptions"]["exception"]) == str:
                    ex.append(con_file_typ["exceptions"]["exception"])
                if type(con_file_typ["exceptions"]["exception"]) == list:
                    for exep in con_file_typ["exceptions"]["exception"]:
                        ex.append(exep)
                methods["exceptions"] = {"exception": ex}
            if "return" in con_file_typ:
                methods["return"] = con_file_typ["return"]

            list_check.append(methods)

    # abstract_method from xml file and make json file
    parsar_obj = {"abstract_method": list_check}
    Str_dict = json.dumps(parsar_obj, indent=2)
    print("Data converted successful")

    file_make(Str_dict)


def file_make(files):

    with open("WebService.json", "w") as outfile:
        print("New json file is created name is WebService.json check is folder")
        outfile.write(files)


if __name__ == '__main__':
    main()
