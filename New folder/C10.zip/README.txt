read the file bofore run the code

Use IDE to run the file

WebServiceParser.py 

run the code and enter the file name

first past the xml file in script the folder 

after completion of code you see the output json file in folder