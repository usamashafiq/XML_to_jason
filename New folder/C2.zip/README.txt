you should install followings

pip install xmltodict

pip install xml

pip install json

then use the script

python WebServiceParser.py -f WebService.xml

input the file name .xml which is already present in .py folder
