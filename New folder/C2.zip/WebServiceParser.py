import argparse
import xmltodict
import json


def Json_file(data):
    data_dict = {}
    if "@name" in data:
        data_dict["method_name"] = data['@name']
    if "visibility" in data:
        data_dict["visibility"] = data["visibility"]
    limit = []
    an = []
    if "exceptions" in data:
        if type(data["exceptions"]["exception"]) == str:
            an.append(data["exceptions"]["exception"])
        if type(data["exceptions"]["exception"]) == list:
            for anom in data["exceptions"]["exception"]:
                an.append(anom)
        data_dict["exceptions"] = {"exception": an}

    if "arguments" in data:
        for par in data["arguments"]:
            if type(data["arguments"][par]) == list:
                for val in data["arguments"][par]:
                    tmp = {"datatype": val["@type"], "label": val["#text"]}
                    limit.append(tmp)
            if type(data["arguments"][par]) == dict:
                val = data["arguments"][par]
                tmp = {"datatype": val["@type"], "label": val["#text"]}
                limit.append(tmp)
        data_dict["arguments"] = {"parameter": limit}

    if "return" in data:
        data_dict["return"] = data["return"]
    return data_dict


def analyze(xml_file):
    # result = {"abstract_method": []}
    Final_list = []
    with open(xml_file) as xf:
        xml = xmltodict.parse(xf.read())
        try:
            abstract_methods = xml["service"]["abstract_method"]
        except:
            print("There is no at least one abstract_method")
            return
        if type(abstract_methods) == dict:
            data_dict = Json_file(abstract_methods)
            Final_list.append(data_dict)
        if type(abstract_methods) == list:
            for data in abstract_methods:
                data_dict = Json_file(data)
                Final_list.append(data_dict)
        json_obj = {"abstract_method": Final_list}
        json_formatted = json.dumps(json_obj, indent=2)
        print(json_formatted)


def main():
    Pass_file = argparse.ArgumentParser(description='Return the abstract methods in json format after parsing the xml '
                                                    'file.')
    Pass_file.add_argument('-f', '--file', help='file name', required=True)
    argument = vars(Pass_file.parse_args())
    xml_file = argument['file']
    analyze(xml_file)


if __name__ == '__main__':
    main()
